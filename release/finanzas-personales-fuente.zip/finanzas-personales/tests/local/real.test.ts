// Prueba local con un documento real (NO se versiona: tests/local está en .gitignore).
import { it } from 'vitest';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { extractPdfText, type PdfLib } from '../../src/importers/pdf';
import { parseStatementText, reconcile, checkUpcoming } from '../../src/importers/statementParser';
const require = createRequire(import.meta.url);
(pdfjs as unknown as { GlobalWorkerOptions: { workerSrc: string } }).GlobalWorkerOptions.workerSrc = require.resolve('pdfjs-dist/legacy/build/pdf.worker.mjs');
it.skipIf(!process.env.REAL_PDF)('documento real', async () => {
  const { result } = await extractPdfText(pdfjs as unknown as PdfLib, new Uint8Array(readFileSync(process.env.REAL_PDF!)));
  const d = parseStatementText(result.lines);
  const f = (x: { value?: unknown }) => x.value;
  console.log({ entity: f(d.entity), closing: f(d.closingDate), due: f(d.dueDate), month: d.month, total: f(d.total), min: f(d.minimumPayment), prev: f(d.previousBalance), nextC: f(d.nextClosingDate), nextD: f(d.nextDueDate), upcoming: d.upcoming });
  for (const i of d.items) console.log(i.kind.padEnd(12), i.date, (i.amount! / 100).toFixed(2).padStart(12), i.installment ? `${i.installment.n}/${i.installment.total}` : '   ', i.confidence, '|', i.concept, '|', i.suggestedCategory);
  console.log('conciliación', reconcile(d.previousBalance.value, d.total.value, d.items));
  console.log('cuotas a vencer', checkUpcoming(d.upcoming, d.items));
  console.log('avisos', d.warnings, d.undetermined);
});

import { freshDb } from '../unit/helpers';
import { buildReview, commitReview, validateReview, verifyReview } from '../../src/importers/review';
import { loadDataSet } from '../../src/db/repo';
import { computeMonth } from '../../src/domain/monthly';
import { buildSchedule } from '../../src/domain/obligations';
import '../unit/setup';
it.skipIf(!process.env.REAL_PDF)('flujo completo con documento real', async () => {
  const db = await freshDb();
  const bytes = new Uint8Array(readFileSync(process.env.REAL_PDF!));
  const { result } = await extractPdfText(pdfjs as unknown as PdfLib, bytes.slice());
  const parsed = parseStatementText(result.lines);
  const r = await buildReview(parsed, { name: 'real.pdf', size: bytes.length, mime: 'application/pdf', kind: 'pdf', hash: 'x' }, false, db, '2026-10');
  console.log('acciones', r.items.map((i) => `${i.action}${i.include ? '' : '(no)'}`).join(', '));
  console.log('problemas', validateReview(r));
  console.log('verificación', JSON.stringify(verifyReview(r).balance));
  const res = await commitReview(r, null, db);
  console.log('creado', res.created);
  const data = await loadDataSet(db);
  const m = computeMonth(data, '2026-10', '2026-10');
  for (const s of m.sections) console.log(s.title.padEnd(40), (s.total / 100).toFixed(2));
  for (const o of data.obligations) console.log('OB', o.concept, o.type, `${o.paidInstallments}/${o.totalInstallments}`, o.nextDueMonth, buildSchedule(o, '2026-10').filter((i) => i.status === 'pendiente').map((i) => i.month).join(','));
  const nov = computeMonth(data, '2026-11', '2026-10');
  console.log('cuotas nov', nov.sections.find((s) => s.key === 'obligaciones')!.total / 100, 'dic', computeMonth(data, '2026-12', '2026-10').sections.find((s) => s.key === 'obligaciones')!.total / 100);
  console.log('sancor esperado', m.info.sancorExpected / 100, 'resumen', m.info.statementsTotal / 100);
});
