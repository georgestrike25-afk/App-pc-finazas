// Prueba local con un extracto real (NO se versiona).
import { it } from 'vitest';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import '../unit/setup';
import { freshDb } from '../unit/helpers';
import { extractPdfText, type PdfLib } from '../../src/importers/pdf';
import { parseBankExtract } from '../../src/importers/bankExtract';
import { buildReview, commitReview, validateReview } from '../../src/importers/review';
import { loadDataSet } from '../../src/db/repo';
import { computeMonth } from '../../src/domain/monthly';
const require = createRequire(import.meta.url);
(pdfjs as unknown as { GlobalWorkerOptions: { workerSrc: string } }).GlobalWorkerOptions.workerSrc = require.resolve('pdfjs-dist/legacy/build/pdf.worker.mjs');
it.skipIf(!process.env.UALA)('extracto Ualá real', async () => {
  const { result } = await extractPdfText(pdfjs as unknown as PdfLib, new Uint8Array(readFileSync(process.env.UALA!)));
  const d = parseBankExtract(result.lines)!;
  console.log('entidad', d.entity.value, 'mes', d.month, 'movimientos', d.items.length, JSON.stringify(d.accountCheck));
  const db = await freshDb();
  const r = await buildReview(d, { name: 'u.pdf', size: 1, mime: 'application/pdf', kind: 'pdf', hash: 'u' }, false, db, '2026-10');
  console.log('problemas', validateReview(r).length);
  const by = new Map<string, { n: number; total: number }>();
  for (const it of r.items) {
    const k = `${it.include ? '✔' : ' '} ${it.action.padEnd(12)} ${it.parsedKind.padEnd(13)} ${it.include ? it.category : ''}`;
    const e = by.get(k) ?? { n: 0, total: 0 };
    e.n++;
    e.total += it.amount ?? 0;
    by.set(k, e);
  }
  for (const [k, v] of [...by.entries()].sort()) console.log(k.padEnd(60), String(v.n).padStart(3), (v.total / 100).toFixed(2).padStart(14));
  for (const it of r.items.filter((x) => x.parsedKind === 'consumo' && x.category === 'Transferencias').slice(0, 6)) console.log('  ', it.concept, (it.amount! / 100).toFixed(2));
  await commitReview(r, null, db);
  const data = await loadDataSet(db);
  data.settings.monthBudgets['2026-09'] = { amount: 0, mode: 'real' };
  const m = computeMonth(data, '2026-09', '2026-10');
  for (const s of m.sections) console.log(s.title.padEnd(40), (s.total / 100).toFixed(2));
});
