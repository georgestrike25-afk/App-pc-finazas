// Prueba local con una captura real (NO se versiona).
import { it } from 'vitest';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import '../unit/setup';
import { freshDb } from '../unit/helpers';
import { extractPdfText, type PdfLib } from '../../src/importers/pdf';
import { parseStatementText } from '../../src/importers/statementParser';
import { parseAccountMovements } from '../../src/importers/accountMovements';
import { detectLoanSchedule } from '../../src/importers/loanSchedule';
import { buildLoanReview, commitLoanReview } from '../../src/importers/loanReview';
import { buildReview, commitReview } from '../../src/importers/review';
import { loadDataSet } from '../../src/db/repo';
import { computeMonth } from '../../src/domain/monthly';
const require = createRequire(import.meta.url);
(pdfjs as unknown as { GlobalWorkerOptions: { workerSrc: string } }).GlobalWorkerOptions.workerSrc = require.resolve('pdfjs-dist/legacy/build/pdf.worker.mjs');
const U = '/root/.claude/uploads/49b54419-879c-5d03-b572-d1135039eae3/';
async function pdfLines(f: string) {
  const { result } = await extractPdfText(pdfjs as unknown as PdfLib, new Uint8Array(readFileSync(U + f)));
  return result.lines;
}
it.skipIf(!process.env.OCR_LINES)('captura de cuenta real', async () => {
  const db = await freshDb();
  for (const f of ['de7f8ccb-cronogramaPrestamo.pdf', '025dba2c-cronogramaPrestamo1.pdf']) {
    const ls = await pdfLines(f);
    await commitLoanReview(await buildLoanReview(detectLoanSchedule(ls)!, { name: f, size: 1, mime: 'application/pdf', kind: 'pdf', hash: f }, '', db), null, db);
  }
  const vl = await pdfLines('82a4bb49-resumenTarjetaCredito.01-oct-2026_1.pdf');
  await commitReview(await buildReview(parseStatementText(vl), { name: 'visa', size: 1, mime: 'application/pdf', kind: 'pdf', hash: 'v' }, false, db, '2026-10'), null, db);

  const lines = readFileSync(process.env.OCR_LINES!, 'utf8').split('\n').filter(Boolean).map((l) => {
    const i = l.indexOf('| ');
    return { text: l.slice(i + 2), ocrConfidence: Number(l.slice(0, i)) };
  });
  const d = parseAccountMovements(lines)!;
  console.log('entidad', d.entity.value, 'mes', d.month, 'items', d.items.length);
  const r = await buildReview(d, { name: 'captura.jpg', size: 1, mime: 'image/jpeg', kind: 'imagen', hash: 'c' }, true, db, '2026-10');
  for (const it of r.items) console.log((it.include ? '✔' : ' ') + ' ' + it.action.padEnd(9), it.parsedKind.padEnd(14), it.date, (it.amount! / 100).toFixed(2).padStart(12), it.confidence, '|', it.concept, '|', it.duplicate?.label ?? '');
  const res = await commitReview(r, null, db);
  console.log(res.created);
  const data = await loadDataSet(db);
  const m = computeMonth(data, '2026-10', '2026-10');
  for (const s of m.sections) console.log(s.title.padEnd(40), (s.total / 100).toFixed(2));
  console.log('saldo oct', m.available / 100, 'pagos tarjeta', m.info.cardPaymentsTotal / 100);
  for (const o of data.obligations.filter((x) => x.type === 'prestamo')) console.log(o.concept, o.paidInstallments, o.nextDueMonth);
  console.log(data.incomes.map((i) => [i.month, i.amountReceived / 100, i.receivedDate]));
  console.log('pago vinculado', data.cardPayments.map((p) => [p.date, p.amount / 100, !!p.statementId]));
});
