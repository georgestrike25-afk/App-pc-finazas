import { it } from 'vitest';
import { readFileSync } from 'node:fs';
import { parseAccountMovements } from '../../src/importers/accountMovements';
import { parseBankExtract } from '../../src/importers/bankExtract';
import { parseCardActivity } from '../../src/importers/cardActivity';
it('otros lectores no la toman', () => {
  const lines = JSON.parse(readFileSync(process.env.ULINES!, 'utf8'));
  console.log('account', !!parseAccountMovements(lines), 'bank', !!parseBankExtract(lines), 'card', !!parseCardActivity(lines));
});
