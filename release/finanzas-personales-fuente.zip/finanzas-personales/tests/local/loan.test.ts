// Prueba local con cronogramas reales (NO se versiona).
import { it } from 'vitest';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import '../unit/setup';
import { freshDb } from '../unit/helpers';
import { extractPdfText, type PdfLib } from '../../src/importers/pdf';
import { detectLoanSchedule, summarizeLoan } from '../../src/importers/loanSchedule';
import { buildLoanReview, commitLoanReview } from '../../src/importers/loanReview';
import { parseStatementText } from '../../src/importers/statementParser';
import { loadDataSet } from '../../src/db/repo';
import { buildSchedule, computedBalance } from '../../src/domain/obligations';
import { computeMonth } from '../../src/domain/monthly';
const require = createRequire(import.meta.url);
(pdfjs as unknown as { GlobalWorkerOptions: { workerSrc: string } }).GlobalWorkerOptions.workerSrc = require.resolve('pdfjs-dist/legacy/build/pdf.worker.mjs');
it.skipIf(!process.env.LOAN_PDFS)('cronogramas reales', async () => {
  const db = await freshDb();
  for (const f of process.env.LOAN_PDFS!.split('|')) {
    const bytes = new Uint8Array(readFileSync(f));
    const { result } = await extractPdfText(pdfjs as unknown as PdfLib, bytes.slice());
    const s = detectLoanSchedule(result.lines)!;
    const sm = summarizeLoan(s.rows, '2026-10-20');
    console.log(s.loanType, s.loanNumber, s.rows.length, s.warnings, { pagadas: sm.paidCount, prox: sm.nextRow, falta: sm.remainingTotal / 100, capital: sm.remainingCapital! / 100, interes: sm.remainingInterestAndTaxes! / 100, original: sm.originalCapital! / 100, ultima: sm.lastRow.dueDate });
    const r = await buildLoanReview(s, { name: 'c.pdf', size: 1, mime: 'application/pdf', kind: 'pdf', hash: f }, result.lines.map((l) => l.text).join('\n'), db);
    await commitLoanReview(r, null, db);
    // El mismo cronograma como resumen de tarjeta no debe dar movimientos
    console.log('como resumen:', parseStatementText(result.lines).items.length);
  }
  const data = await loadDataSet(db);
  for (const o of data.obligations) {
    const sc = buildSchedule(o, '2026-10');
    console.log(o.concept, `${o.paidInstallments}/${o.totalInstallments}`, o.nextDueMonth, 'saldo', computedBalance(o, '2026-10'), 'nov', sc.find((i) => i.month === '2026-11')?.amount);
  }
  console.log('cuotas nov 2026', computeMonth(data, '2026-11', '2026-10').sections.find((x) => x.key === 'obligaciones')!.total / 100);
  // Reimportar no duplica
  const f = process.env.LOAN_PDFS!.split('|')[0];
  const { result } = await extractPdfText(pdfjs as unknown as PdfLib, new Uint8Array(readFileSync(f)));
  const r2 = await buildLoanReview(detectLoanSchedule(result.lines)!, { name: 'c.pdf', size: 1, mime: 'application/pdf', kind: 'pdf', hash: f }, '', db);
  console.log('existente', !!r2.existing, r2.warnings[0]);
  await commitLoanReview(r2, null, db);
  console.log('obligaciones', (await loadDataSet(db)).obligations.length);
});
