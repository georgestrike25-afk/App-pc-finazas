import { it } from 'vitest';
import { readFileSync } from 'node:fs';
import { parseCardActivity } from '../../src/importers/cardActivity';
it('video Naranja', () => {
  const lines = JSON.parse(readFileSync(process.env.VLINES!, 'utf8'));
  const d = parseCardActivity(lines)!;
  console.log(d.entity.value, d.closingDate.value, d.month, JSON.stringify(d.activityCheck), d.warnings);
  for (const i of d.items) console.log(i.kind, i.date, i.concept, i.amount! / 100, JSON.stringify(i.installment), i.suggestedCategory, i.confidence);
});
