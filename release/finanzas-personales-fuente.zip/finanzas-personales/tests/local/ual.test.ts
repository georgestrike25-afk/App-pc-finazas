import { it } from 'vitest';
import { readFileSync } from 'node:fs';
import { parseWalletMovements } from '../../src/importers/walletMovements';
it('ual', () => {
  const lines = JSON.parse(readFileSync(process.env.ULINES!, 'utf8'));
  const d = parseWalletMovements(lines, { partnerName: 'Antonella', fileName: 'Screen_Recording_20261022_140724_Ual.mp4', today: '2026-10-22' })!;
  console.log(d.entity.value, d.month, d.items.length);
  for (const i of d.items) console.log(i.kind, i.date, i.concept, i.amount! / 100, i.direction, i.cancelsOut ? 'ANULA' : '', i.suggestedCategory);
});
