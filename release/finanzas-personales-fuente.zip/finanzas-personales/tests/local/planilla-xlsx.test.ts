import { it } from 'vitest';
import { readFileSync } from 'node:fs';
import { parseSpreadsheet, rowsToLines } from '../../src/importers/tabular';
import { detectSharedSheet, sheetRows } from '../../src/importers/sharedSheet';
it('xlsx real', async () => {
  const rows = await parseSpreadsheet(new Uint8Array(readFileSync(process.env.XLSX!)));
  for (const r of rows.slice(0, 14)) console.log(JSON.stringify(r));
  const { lines } = rowsToLines(rows);
  const sh = detectSharedSheet(lines, { fileName: 'Gastos_Compartidos_Jor_y_Anto_2026.xlsx', fallbackYear: 2026 });
  if (!sh) return console.log('NO DETECTADA');
  console.log(JSON.stringify(sh.groups), sh.warnings);
  const r = sheetRows(sh, 'Jorge', [], '2026-10');
  for (const x of r.rows.filter((x) => x.month === '2026-10' || x.month === '2026-07')) console.log(x.month, x.concept, x.kind, x.total / 100, x.userPct, x.user / 100);
  console.log(r.skipped, sh.values.length);
});
