import { it, expect } from 'vitest';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { extractPdfText, type PdfLib } from '../../src/importers/pdf';
import { detectSharedSheet, sheetRows } from '../../src/importers/sharedSheet';
import { detectPaymentPlan } from '../../src/importers/paymentPlan';
import { detectLoanSchedule } from '../../src/importers/loanSchedule';
const require = createRequire(import.meta.url);
(pdfjs as any).GlobalWorkerOptions.workerSrc = require.resolve('pdfjs-dist/legacy/build/pdf.worker.mjs');

it('planilla real de gastos compartidos', async () => {
  const f = process.env.COMP!;
  const { result } = await extractPdfText(pdfjs as unknown as PdfLib, new Uint8Array(readFileSync(f)));
  expect(detectPaymentPlan(result.lines)).toBeNull();
  expect(detectLoanSchedule(result.lines)).toBeNull();
  const sh = detectSharedSheet(result.lines, { fileName: 'Gastos_Compartidos_Jor_y_Anto_2026_.pdf', fallbackYear: 2026 })!;
  console.log(JSON.stringify({ people: sh.people, groups: sh.groups, warnings: sh.warnings }));
  for (const v of sh.values) console.log(v.month, v.group, v.person, v.amount / 100, v.raw);
  const r = sheetRows(sh, 'Jorge', [], '2026-10');
  for (const x of r.rows) console.log(x.include ? '✓' : '·', x.month, x.concept, x.kind, x.total / 100, x.userPct, x.user / 100, x.note ?? '');
  console.log(r.skipped);
});
