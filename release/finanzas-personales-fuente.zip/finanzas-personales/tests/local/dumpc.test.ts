import { it } from 'vitest';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
import { extractPdfText, type PdfLib } from '/home/user/App-pc-finazas/src/importers/pdf';
const require = createRequire(import.meta.url);
(pdfjs as any).GlobalWorkerOptions.workerSrc = require.resolve('pdfjs-dist/legacy/build/pdf.worker.mjs');
it('dump', async () => {
  const b = new Uint8Array(readFileSync(process.env.PDF!));
  const { result } = await extractPdfText(pdfjs as unknown as PdfLib, b);
  writeFileSync(process.env.OUT!, result.lines.map((l) => `p${l.page}|${(l.cells ?? []).map((c) => c.s + '@' + Math.round(c.x)).join(' ¦ ')}`).join('\n'));
});
